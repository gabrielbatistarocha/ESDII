public class Mapa<K, V> {

    private static class Node<K, V> {
        K key;
        V value;
        Node<K, V> next;
        Node<K, V> prev;

        public Node(K key, V value) {
            this.key = key;
            this.value = value;
            this.next = null;
            this.prev = null;
        }
    }

    private Node<K, V> head; 
    private Node<K, V> tail; 

    public Mapa() {
        head = null;
        tail = null;
    }

    public void put(K chave, V valor) {
        Node<K, V> newNode = new Node<>(chave, valor);

        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    public V get(K chave) {
        Node<K, V> currentNode = head;
        while (currentNode != null) {
            if (currentNode.key.equals(chave)) {
                return currentNode.value;
            }
            currentNode = currentNode.next;
        }
        return null; 
    }

    public void remove(K chave) {
        Node<K, V> currentNode = head;

        while (currentNode != null) {
            if (currentNode.key.equals(chave)) {
                if (currentNode.prev != null) {
                    currentNode.prev.next = currentNode.next;
                } else {
                    head = currentNode.next;
                }
                if (currentNode.next != null) {
                    currentNode.next.prev = currentNode.prev;
                } else {
                    tail = currentNode.prev;
                }
                return; 
            }
            currentNode = currentNode.next;
        }
    }
    public int size() {
        int count = 0;
        Node<K, V> currentNode = head;
        while (currentNode != null) {
            count++;
            currentNode = currentNode.next;
        }
        return count;
    }

    public static void main(String[] args) {
        Mapa<String, Integer> mapa = new Mapa<>();
        mapa.put("Primeiro", 1);
        mapa.put("Segunda", 2);
        mapa.put("Terceira", 3);
        System.out.println("O tamanho do mapa é " + mapa.size());
        System.out.println("O valor da primeira chave é " + mapa.get());
        System.out.println("O valor da segunda chave é " + mapa.get());
        System.out.println("O valor da terceira chave é " + mapa.get());
        mapa.remove("Segunda");
        System.out.println("O Tamanho do mapa após remover a segunda chave é " + mapa.size());
    }
}