public class MapaTest {

    public static void main(String[] args) {
        testPutAndGet();
        testRemover();
        testSize();
    }

    public static void testPutAndGet() {
        Mapa<String, Integer> mapa = new Mapa<>();
        mapa.put("primeiro", 1);
        mapa.put("segundo", 2);
        assert mapa.get("primeiro").equals(1);
        assert mapa.get("segundo").equals(2);
        assert mapa.get("terceiro") == null;
    }

    public static void testRemove() {
        Mapa<String, Integer> mapa = new Mapa<>();
        mapa.put("primeiro", 1);
        mapa.put("segundo", 2);
        mapa.remove("primeiro");

        assert mapa.get("primeiro") == null;
        assert mapa.size() == 1;
    }

    public static void testSize() {
        Mapa<String, Integer> mapa = new Mapa<>();

        assert mapa.size() == 0;
        mapa.put("primeiro", 1);
        assert mapa.size() == 1;
        mapa.put("segundo", 2);
        assert mapa.size() == 2;
        mapa.remove("primeiro");
        assert mapa.size() == 1;
    }
}
